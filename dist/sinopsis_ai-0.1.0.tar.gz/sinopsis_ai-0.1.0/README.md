# Sinopsis AI SDK

A Python SDK for interacting with Sinopsis AI, designed to simplify the process of logging user prompts and responses, and managing conversation data.

## Installation

You can install the package using pip:

```bash
pip install sinopsis_ai